<?php /* Template name: executive */
get_header(); ?>

<?php get_footer(); ?>
